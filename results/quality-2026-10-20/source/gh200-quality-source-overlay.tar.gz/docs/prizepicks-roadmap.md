# PrizePicks portfolio direction

Reviewed October 20, 2026, against this repository's integrated performance and power code.

The [H200 validation review](h200-review.md) records the new real-GPU run. All 24 sustained
workload windows passed verification, but the fixed H100-trained linear model scored **56.78 W
RMSE** on H200 and lost to a training-workload-mean baseline. This makes device/feature-drift
handling and independently evaluated adaptation a concrete priority. Capture date and environment
also differ, so this experiment does not isolate a hardware-only effect.

## What the roles ask for

The [Machine Learning Internship — Spring 2027](https://www.prizepicks.com/position?gh_jid=8038883003)
emphasizes Python, SQL, reliable sports data streams, and moving models into stable, scalable services.
GCP, deployment automation, databases, MLOps, and lower-level languages are differentiators.
The posting was returned by PrizePicks' public Greenhouse API on the review date.

The [Data & ML Platform internship description](https://www.choppingblock.ai/jobs/data-machine-learning-platform-engineering-internship-spring-2027-at-prizepicks)
also emphasizes distributed ETL, Kubernetes, and CPU/GPU architecture. Its original job ID,
8009261003, returned HTTP 404 and was absent from the live employer job feed on the review date.
Use its requirements for portfolio alignment; do not assume the role is still accepting applications.
Both descriptions have a Spring 2027 title but a 2026 program-date line; confirm dates with recruiting.

## Existing evidence and actual gaps

| Hiring signal | Already present | Most valuable next evidence |
| --- | --- | --- |
| Python and C++ | CUDA worker, Python orchestration, bounded subprocesses, correctness checks | Reproducible H200 measurements alongside H100 evidence |
| Data reliability | Raw artifacts, hashes, schemas, resumable sweeps, provenance | Idempotent SQL ingestion with constraints and failure recovery |
| Applied ML | Linear/tree power models, grouped trial evaluation, preprocessing pipeline | Fixed-model external GPU evaluation and held-out workload tests against simple baselines |
| Model operations | Versioned local bundles, FastAPI inference, drift reports | Load-tested API, immutable promoted versions, readiness checks, visible failure metrics |
| Deployment | CPU test/lint GitHub Actions | Built and tested container; a recorded deployment and rollback |
| Kubernetes/GCP | No deployment evidence found | Run a small local Kubernetes demo, then deploy a CPU inference service to GCP if desired |
| Sports context | No sports dataset or task | A small separately scoped sports-model example using the same serving and evaluation practices |

The strongest framing for the existing project is **GPU telemetry ML and performance infrastructure**.
The H200 generates real observations and supports systems experiments. The tabular models can train
and serve on CPU; using a neural network solely to consume the H200 would not establish better ML work.

## Recommended implementation order

### 1. Establish honest model generalization

Use the previously published H100 study to choose a model before examining H200 targets.
Fit preprocessing and weights only on H100 telemetry, then evaluate on measured H200 data.
Report MAE/RMSE, per-workload errors, and training-mean and training-workload-mean baselines.
Keep all measurements and negative results. A failure to transfer is useful evidence for an
out-of-distribution detection and retraining decision, not a successful deployment claim.

The review adds `python -m gpu_power_pipeline.transfer` for this experiment. It rejects overlapping
GPU UUIDs, records input/model hashes, reloads the saved bundle, and emits drift and error reports.
The default linear model comes from the prior H100 result; H200 is not used for model selection.
Cross-device results are also confounded by capture dates and environments.

Next, collect additional independent sessions and workload shapes. Split by whole sessions,
withhold workload families/sizes, select models on validation folds, and evaluate once on a final
test set. Keep future H200 sessions untouched if adapting to the first H200 capture. Add
train-only feature selection to the historical BMC path before presenting that dataset as formal evidence.
Current serving refits on all rows after selection; its earlier holdout score is not a separate
test of that final refitted artifact.

### 2. Add a useful SQL layer

Introduce an experiment warehouse with `devices`, `runs`, `scenarios`, `telemetry_samples`,
`model_versions`, and `predictions`. Preserve immutable raw files and their checksums.
Start with a local analytical database; use PostgreSQL when introducing concurrent writers or services.

Implement ingestion keyed by run/scenario/sample identity, foreign-key and value checks,
transactional retries, and a recorded schema version. Use SQL joins to connect predictions to
observed targets and compute per-device/workload errors and performance regressions.

Acceptance evidence: ingest a real capture twice without duplication; interrupt and retry an
ingestion; reject inconsistent run identity; reproduce published aggregates with SQL; retain
malformed records with reasons. Report actual row counts and measured ingestion rates.

### 3. Harden and measure the existing serving path

The existing API accepts almost-empty telemetry and has no batch limit. Its health endpoint returns
HTTP 200 even without a loaded model, and prediction-log errors are not exposed. Those behaviors
matter more for a portfolio service than adding another model family.

Require the model's feature contract, reject nonfinite/out-of-range inputs, bound request sizes,
and distinguish liveness from readiness. Pin an immutable model version at deployment, record
version and input identity for predictions, and expose error/latency/drift metrics.

Benchmark warm and cold requests, batch sizes, and concurrent clients over HTTP. Report p50/p95/p99,
throughput, error rate, hardware, and payload size. Treat in-process API tests as functional checks;
they do not measure deployment or network performance. Use a version rollback demonstration as evidence.

### 4. Demonstrate one deployment path

Build a container and reproduce training-to-registry-to-serving from a clean environment. CI should
check schema and prediction contracts, build the image, and smoke-test a pinned model artifact.
Use a small local Kubernetes deployment with readiness probes and CPU/memory requests to demonstrate
platform concepts. Separate GPU collection jobs from the CPU model service.

A later GCP deployment can demonstrate cloud delivery, provided it is actually executed and measured.
Keep cloud setup out of résumé claims until there are deployment logs, a health check, and a recorded rollback.
Do not add Kafka, Spark, or a multi-node cluster without a workload that needs them.

### 5. Add sports context as a bounded example

For the ML internship, consider a small NBA player-stat prediction example backed by a documented,
licensed historical dataset. Use SQL to build rolling features from earlier games only; retain
event and availability timestamps; split chronologically and compare against a rolling-average baseline.
If predicting probabilities, evaluate calibration as well as accuracy.

Serve that model through the same deployment practices and replay historical events to test freshness,
duplicates, and late arrivals. Label replay as replay. This establishes relevant domain interest
without claiming access to PrizePicks data or inferring profitable betting performance.

## Résumé evidence rules

Lead with the problem, implementation, and measured outcome. Use at most three project bullets.
For the ML application, prioritize evaluation, feature/data handling, and serving. For the platform
application, prioritize reliability, SQL, deployment, and CPU/GPU performance.

Existing published evidence supports statements such as:

- Built a Python/CUDA experiment pipeline covering six kernels and 74 configurations; retained
  11,100 H100 timing samples with correctness checks and source/binary provenance.
- Evaluated GPU board-power models using entire held-out H100 trials; linear regression achieved
  3.11 W mean RMSE across three folds on 1,123 measured telemetry samples.
- Implemented versioned model persistence, batch and FastAPI inference, and feature-drift reports.

The H100 score measures repeat-session behavior on one GPU. It is not a cross-device score.
The API exists locally; it is not evidence of a cloud deployment or an achieved latency target.
Replace future SQL, deployment, and service-performance claims with measured results only after their checks pass.

Related evidence: [H100 model report](../results/h100-power-model-2026-09-22/REPORT.md),
[engineering decisions](engineering.md), [power methodology](power_measurement.md).

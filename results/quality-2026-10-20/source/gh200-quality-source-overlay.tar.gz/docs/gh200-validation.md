# Native H100 / H200 / GH200 validation

**GH200 has not been run yet.** This is a reproducible protocol for running on the other cluster once access is available. Obtain its official login/portal and GPU allocation instructions from the cluster operator; run these commands inside an allocated GPU node, never a login node.

GH200 combines an Arm Grace CPU and Hopper GPU ([NVIDIA architecture description](https://docs.nvidia.com/dccpu/index.html)). An H200 result from an x86_64 host does not validate GH200. Build locally on each allocated machine; create a new native Python environment on GH200 (`aarch64`) and install project dependencies there using the site's supported Python/CUDA toolchain. Do not copy an x86_64 virtual environment, compiled wheels, build directory, or benchmark executable. The workflow never installs dependencies or changes clocks, power limits, modules, or system settings.

After loading the site's CUDA toolkit (Hopper-capable nvcc and CMake >=3.21) and preparing a native Python >=3.10 environment with this project installed, run:

```bash
# Use the exact allocated full-GPU UUID reported by nvidia-smi.
GPU_UUID=GPU-<allocated-uuid> PYTHON=/path/to/native/venv/bin/python \
  MODE=smoke bash scripts/cross_validate_gpu.sh

GPU_UUID=GPU-<allocated-uuid> PYTHON=/path/to/native/venv/bin/python \
  MODE=full bash scripts/cross_validate_gpu.sh
```

`MODE=smoke` runs the boundary correctness suite and validates its artifacts; it is not performance evidence. `MODE=full` (the default, preserving earlier usage) runs the baseline, three scaling trials, edge checks, artifact validation, and timing summary. Run smoke first, then full serially on an idle, exclusively allocated device. Do not overlap power capture, another benchmark, or another user's GPU workload. The preflight is an initial check, not a scheduler lock; exclusive allocation must prevent later interference.

`PYTHON`, `OUT_DIR`, and `BUILD_DIR` remain configurable. The default output is `outputs/<GPU-UUID>/<UTC-time>-<pid>/`, with its own fresh build subdirectory. Existing nonempty output/build directories are rejected to prevent cache and binary reuse. `CUDA_ARCHITECTURES` is detected from the selected GPU's compute capability (Hopper is 90); if supplied, it must match. No host library directory is hardcoded. Existing single-device `CUDA_VISIBLE_DEVICES` is respected and checked against `GPU_UUID`; multiple devices, partial UUIDs, MIG, unknown utilization, active compute processes, and conflicting selections fail conservatively. A single physical nvidia-smi index is accepted, then normalized to the exact UUID. The CUDA runtime independently confirms that ordinal zero has the PCI bus address associated with that UUID, and all build/benchmark subprocesses inherit that one-device visibility.

`preflight.json` records host architecture, native Python path/version, GPU UUID/name/driver/memory/clocks/power limit, resolved runtime library and runtime/compiler/CMake versions, git revision/status, tracked dirty diff, and untracked filenames. `requirements-lock.txt`, build/configure logs, final GPU state, and the suite artifacts accompany it. Untracked source contents are not copied: commit intended source or archive those files explicitly for exact reproduction. Avoid placing secrets in source diffs. Preflight and version discovery are read-only; CUDA context initialization may briefly reserve device memory. If a failure leaves partial output, preserve it for diagnosis and choose a fresh output directory for retry.

Power is a separate experiment: first finish the timing workflow, then use the repository's power capture CLI with the same selected UUID/native environment and a fresh output path. Power sample periods must cover enough repeated work to produce measured (not empty) samples; keep power and timing results labeled separately. The timing command above makes no energy claim.

For H100/H200/GH200 comparison, retain all three per-device run directories, compare identical scenario/kernel/problem/block identifiers, review all three timing trials and correctness, and record differences in memory capacity, clocks/power limit, driver/toolkit and host CPU. GH200's coherent Grace memory is not automatically exercised by these device-allocation kernels; this protocol tests the existing kernels, not CPU–GPU coherent-memory performance.

CPU-only guard checks: `python -m pytest -q tests/test_hardware_preflight.py`; shell syntax: `bash -n scripts/cross_validate_gpu.sh`. Actual GH200 evidence requires successful smoke/full runs on the other cluster and inspection of saved artifacts.
